# tunnel accident detectio > 2023-10-10 2:11pm
https://universe.roboflow.com/tru-projects-7dbwp/tunnel-accident-detectio

Provided by a Roboflow user
License: CC BY 4.0

